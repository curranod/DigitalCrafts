const express = require('express')
const app = express()
const mustacheExpress = require('mustache-express')
const models = require('./models')

const { Op } = require('sequelize') // Operator 

app.use(express.urlencoded())

// setting up Express to use Mustache Express as template pages 
app.engine('mustache', mustacheExpress())
    // the pages are located in views directory
app.set('views', './views')
    // extension will be .mustache
app.set('view engine', 'mustache')

app.post('/add-movie', async (req, res) => {

    const title = req.body.title 
    const genre = req.body.genre 
    const year = parseInt(req.body.year) 

    // create the Movie Object // build is not going to save the object but just build it 
    const movie = models.Movie.build({
        title: title, 
        genre: genre, 
        year: year 
    })

    // save the movie to the database 
    const savedMovie = await movie.save()
    console.log(savedMovie)
})

app.get('/movies/genre/:genre', async (req, res) => {
 
    const genre = req.params.genre 
    const movies = await models.Movie.findAll({
        where: {
            genre: {
                [Op.iLike]: genre 
            }
        }
    })
    res.json(movies) // but you should render a mustache page 
})

// deleting a movie 
app.post('/delete-movie', async (req, res) => {

    const movieId = parseInt(req.body.movieId) 
    const deletedMovie = await models.Movie.destroy({
        where: {
            id: movieId
        }
    })

    res.json(deletedMovie) // but you should render a mustache page 

})

app.get('/movies/:movieId', async (req, res) => {
    
    const movieId = parseInt(req.params.movieId) 
    let movie = await models.Movie.findByPk(movieId)
    res.json(movie) // but you should render a mustache page 

})

app.get('/', async (req, res) => {
    const movies = await models.Movie.findAll({})
    console.log(movies)
    res.render('index', {movies: movies})
})

app.listen(8080,() => {
    console.log('Server is running...')
})


